#include <logging_mosq.h>

int log__printf(struct mosquitto *mosq, int priority, const char *fmt, ...)
{
	return 0;
}
